# Part 1 — Next.js Integration (for Claude Code in `aiwizn-website`)

The engine HTML is finished and its Supabase persistence is wired and tested.
This doc covers the remaining work: adding it to `aiwizn-website` as a third
engine, following the **exact JC 2026 pattern** already in the repo.

## What's already done (do NOT redo)

- The engine is a finished standalone file: `patient-care-onboarding-engine_LATEST.html`.
- Its save/load is wired to Supabase table `public.pco_onboarding_records`
  (project `scyfldezhztapttcyenr`). RLS owner-scoped; verified.
- The engine reads its Supabase config from **query params** `supabaseUrl` and
  `supabaseKey`. It authenticates via the session cookies (same-origin iframe),
  NOT from the URL. No `ALLOWED_EMAILS`, no magic-link screen — auth is
  inherited from the aiwizn.com dashboard gate.

## The 5-file change (mirror `jc2026` exactly)

1. **Place the engine file** at:
   `public/engines/patient-care-onboarding/index.html`
   (copy `patient-care-onboarding-engine_LATEST.html` there, rename to `index.html`)

2. **Create the route page** at:
   `app/(app)/dashboard/engines/patient-care-onboarding/page.tsx`
   — clone `app/(app)/dashboard/engines/jc2026/page.tsx`, then:
   - swap the `ENGINE_URL` constant
   - swap the page title + iframe `title` strings
   - **IMPORTANT — the iframe `src` must append the Supabase params** so the
     engine can reach the DB. Build it like:
     `` `${ENGINE_URL}?supabaseUrl=${encodeURIComponent(process.env.NEXT_PUBLIC_SUPABASE_URL!)}&supabaseKey=${encodeURIComponent(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)}` ``
     (The clinical/jc2026 pages don't do this — onboarding needs it because it
     reads/writes Supabase from inside the iframe. This is the one real
     deviation from the jc2026 page.)
   - Keep the per-page `hasActiveEnginesSubscription()` check identical.

3. **Add the engine to the hub** — in `app/(app)/dashboard/engines/page.tsx`,
   append a third entry to the `ENGINES` array:
   `{ id, title: 'Patient Care Onboarding Engine', blurb: '...', href: '/dashboard/engines/patient-care-onboarding' }`
   and change the grid to `md:grid-cols-3`.

4. **Fix stale "two engines" copy** — `engines/page.tsx` subhead (~L46),
   `dashboard/page.tsx` (~L48), and `lib/pricing.ts` `ENGINES_INCLUDED`.

## Verify before commit

- The engine page renders inside the dashboard for a logged-in, subscribed user.
- The iframe URL has the `supabaseUrl` / `supabaseKey` params present.
- Inside the engine: start a session, answer a decision, save — confirm a row
  appears in `pco_onboarding_records` owned by the logged-in user.
- A logged-out user hitting `/dashboard/engines/patient-care-onboarding` is
  redirected to `/login` (inherited gate — should already work).

## Known/accepted

- The raw file at `/engines/patient-care-onboarding/index.html` is publicly
  fetchable (same as jc2026). Accepted for v1 — it's training content, and the
  DB is protected independently by RLS + the anon-grant revoke.

---

## ADDENDUM — review corrections (read before implementing)

A review of this doc against the `aiwizn-website` investigation surfaced three
fixes. Apply these:

### A. "Open in new tab" link MUST carry the Supabase params

The jc2026 page chrome has an `Open in new tab ↗` link pointing at the bare
`ENGINE_URL`. For THIS engine, that link must use the SAME param-decorated URL
as the iframe `src` — otherwise opening in a new tab loads the engine with no
Supabase config and it silently drops to demo/localStorage mode (saves go
nowhere, no error shown).

Fix: build one decorated URL constant and use it for BOTH the iframe `src` and
the new-tab link:
```
const ENGINE_SRC = `${ENGINE_URL}?supabaseUrl=${encodeURIComponent(process.env.NEXT_PUBLIC_SUPABASE_URL!)}&supabaseKey=${encodeURIComponent(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)}`;
```

### B. Verify the env vars BEFORE implementing — two checks

1. Confirm `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` exist
   in `aiwizn-website` (`.env*` and Vercel project settings). A missing/typoed
   var produces an iframe URL with literal `undefined` in the query string.
2. CRITICAL: confirm `NEXT_PUBLIC_SUPABASE_URL` resolves to
   `https://scyfldezhztapttcyenr.supabase.co` — the project where
   `pco_onboarding_records` lives. If `aiwizn-website` uses a different
   Supabase project for its own auth, the engine would authenticate against
   one project and try to write to another, and every save would fail.
   If they differ, STOP and flag it — do not work around it silently.

Reference values (project `scyfldezhztapttcyenr`):
- URL: `https://scyfldezhztapttcyenr.supabase.co`
- Publishable key: `sb_publishable_XVqZASfCKdWY-lOwnJOgvw_KN2nunZ5`

### C. Anon-grant revoke — CONFIRMED in place

The DB-security claim in this doc is verified: `pco_onboarding_records` has
(1) RLS enabled with 4 owner-scoped policies, AND (2) all privileges revoked
from the `anon` role. Verified by direct test: a legitimate authenticated
insert succeeds; a forged-owner_id insert is rejected by RLS; an anonymous
insert is rejected at the privilege level. No action needed — stated here so
the implementer knows the security posture is real, not assumed.

### D. Be explicit: THREE stale-copy locations

When fixing the "two engines" copy, all three must change — do not grep just
one file:
- `app/(app)/dashboard/engines/page.tsx` (~L46 subhead)
- `app/(app)/dashboard/page.tsx` (~L48 — "Clinical Engine or the JC 2026 Engine")
- `lib/pricing.ts` — `ENGINES_INCLUDED` (~L99-110)

### E. Suggested extra verification step

In addition to the verify-before-commit list: with DevTools open inside the
iframe, confirm the Supabase `insert` request to `pco_onboarding_records`
carries the user's JWT in the `Authorization` header. That single check proves
cookie-based auth is propagating through the iframe correctly.
